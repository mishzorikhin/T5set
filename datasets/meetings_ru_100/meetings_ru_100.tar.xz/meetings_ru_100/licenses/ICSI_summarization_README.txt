
ICSI Extractive and Abstractive Summarization
---------------------------------------------

This directory contains files produced using extractive
summary NXT tools. 

For early summaries, coders produced abstractive summaries
in a text buffer and then produced separate extractive
summaries.  Later, we adopted the practice of up-translating
the abstractive summaries into NXT format and modified the
coding tool so that rather than just extracting, coders were
required to link extracts to the parts of the abstractive summary
for which they are relevant.  If for a coder, you can't find these
link files, then check for an early date.  


Using this data in NXT
----------------------

Note that as of NXT 1.3, you should no longer need to edit the
metadata file: lazy loading is implemented so all codings can exist in
the metadata file without being loaded (until they are requested).

These are the metadata extracts; for early data you don't need
the summlink definition (but it won't hurt to include it; you'll
just get a warning that the data wasn't found).  All of these 
coding-file definitions belong within <interaction-codings>.

	    <!-- abstractive summaries are essentially standalone sets
             of sentences grouped into four subheadings: abstract; decisions;
             progress; problems.-->
            <coding-file name="abssumm">
               <structural-layer name="abssumm-layer"  points-to="abstract-section-layer">
                 <code name="abssumm" />
               </structural-layer>
               <structural-layer name="abstract-section-layer"  points-to="sentence-layer">
                 <code name="abstract" />
                 <code name="decisions" />
                 <code name="progress" />
                 <code name="problems" />
               </structural-layer>
               <structural-layer name="sentence-layer">
                 <code name="sentence"  text-content="true"/>
               </structural-layer>
            </coding-file>


	    <!-- extractive summaries which have children in the dialogue act layer -->
            <coding-file name="extsumm">
               <structural-layer name="extsumm-layer"  inherits-time="false" points-to="dialogue-acts-layer">
                 <code name="extsumm" />
               </structural-layer>
            </coding-file>

	    <!-- Links between extractive and abstractive summaries -->
            <coding-file name="summlink">
               <featural-layer name="summlink-layer">
                 <code name="summlink">
                    <pointer number="1" role="extractive" target="dialogue-acts-layer"/>
                    <pointer number="1" role="abstractive" target="sentence-layer"/>
                 </code>
               </featural-layer>
            </coding-file>


The summarization coding GUI additionally requires the topic
segmentation to be present and defined in the metadata because it
displays the topic segments to aid the coder.


GOLD STANDARD
-------------

For abstractive summaries Jonathan Kilgour promoted the following set
of annotators' codings to be treated as the 'gold standard' (though in
fact there was little overlap between annotators). 13th Jan '05

Simone Ashby (sashby)
 Bed009  Bmr007  Bmr012  Bmr016
 Bmr003  Bmr009  Bmr013  Bmr018
 Bmr005  Bmr010  Bmr014  Bmr019
 Bmr006  Bmr011  Bmr015  Bns001

Alastair Gill (alastair)
 Bmr023  Bmr024  Bmr025  Bmr026 Bmr027

Scott Nowson (s9553330)
        Bro010  Bro016  Bro023
Bro003  Bro011  Bro017  Bro024
Bro004  Bro012  Bro018  Bro025
Bro005  Bro013  Bro019  Bro026
Bro007  Bro014  Bro021  Bro027
Bro008  Bro015  Bro022  Bro028

Vasilis Karaiskos (vkaraisk)
 Bdb001 Bed002 Bed003 Bed004 Bed005 Bed006 Bed008 Bed010 Bed011 Bed012
 Bed013 Bed014 Bed015 Bed016 Bed017 Bmr005 Bmr020 Buw001


For extractive summaries, the gold standard and annotators responsible
are the same, but we have no extractive summary for two observations
for which there are abstractive summaries: Bns001 and Bro015

---
summarization status
-according to the checkout at 10:00 GMT+1, 07 APRIL 2005

---
1. annotator tag
a: sashby/simone
b: alastair
c: s9553330/scott
d: vkaraisk/vasilis
e: beata
2. links under extractive/sashby are done by Vasilis, except Bns001 and Bns002
---


       abcde
Bdb001    * 
Bed002    *     
Bed003    *     
Bed004   *** 
Bed005    * 
Bed006    * 
Bed008    * 
Bed009 * ***  
Bed010    * 
Bed011    * 
Bed012    * 
Bed013    * 
Bed014    * 
Bed015    * 
Bed016   *** 
Bed017    * 
Bmr001   *  
Bmr002   *  
Bmr003 *    
Bmr005 *****    
Bmr006 *    
Bmr007 *    
Bmr008   *  
Bmr009 *    
Bmr010 *    
       abcde
Bmr011 *    
Bmr012 *    
Bmr013 *    
Bmr014 *    
Bmr015 *    
Bmr016 *    
Bmr018 *    
Bmr019 * ***
Bmr020    * 
Bmr021    * 
Bmr022    * 
Bmr023  *   
Bmr024  *   
Bmr025  *   
Bmr026  *   
Bmr027  *   
Bmr028    * 
Bmr029    *
Bmr030   * 
Bmr031   * 
Bns001 *    
Bns002 *    
Bns003   *  
Bro003   *  
Bro004   *  
       abcde
Bro005   *  
Bro007   *  
Bro008   *  
Bro010   *  
Bro011   *  
Bro012   *  
Bro013   *  
Bro014   *
Bro015   *
Bro016   *
Bro017   *
Bro018  ****
Bro019   *
Bro021   *
Bro022   *
Bro023   *
Bro024   *
Bro025   *
Bro026   *
Bro027   *
Bro028   *
Bsr001   *
Btr001   *
Btr002   *
Buw001    *
       abcde