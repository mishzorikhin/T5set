from pathlib import Path
import json,re,hashlib,statistics,shutil,zipfile
from collections import Counter
from jsonschema import Draft202012Validator

B=Path(__file__).parent
OUT=B.parent/'meetings_ru_100'
SRC=B/'icsi_annotations'/'ICSIplus'
def dumps(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def obj(properties,description):
    return {'type':'object','description':description,'properties':properties,'required':list(properties),'additionalProperties':False}
def arr(items,description=None):
    r={'type':'array','items':items}
    if description:r['description']=description
    return r
def string(description=None):
    r={'type':'string'}
    if description:r['description']=description
    return r
evidence=obj({'turn_id':{'type':'integer','minimum':0},'quote':string('Дословный фрагмент русской реплики с данным номером.')},'Подтверждение в диалоге.')
task=obj({
 'action':string('Краткое действие в форме инфинитива.'),
 'owners':arr(string(),'Явно названные исполнители: коды участников или имена как в тексте. Не считай инициатора предложения автоматически исполнителем. Если исполнитель не определён, верни [].'),
 'deadline':{'type':['string','null'],'description':'Названный срок или момент выполнения. Сохраняй относительные сроки; не вычисляй календарную дату без опорной даты. Если срок не назван, null.'},
 'conditions':arr(string(),'Явные условия, необходимые предыдущие действия или ограничения выполнения. Не домысливай.'),
 'status':{'type':'string','enum':['committed','requested','proposed'],'description':'committed: участник взял обязательство или действие явно согласовано; requested: есть просьба/поручение без явного принятия; proposed: предварительная идея, возможное действие или неуверенное намерение.'},
 'evidence':arr(evidence,'Минимальные реплики, подтверждающие действие и его атрибуты; несколько соседних реплик можно использовать совместно.')
},'Основное будущее действие. Не включай просто завершённые эксперименты, общие свойства системы, шутки и гипотетические примеры.')
decision_schema=obj({
 'accepted':arr(string(),'Зафиксированные решения и выбранные подходы. Не записывай сюда просто обсуждавшийся вариант.'),
 'proposed':arr(string(),'Основные предварительные варианты, рекомендации и намерения, отличающиеся от принятого решения.')
},'Извлеки основные решения и обсуждавшиеся варианты из полного диалога. Не считай каждую реплику с «нужно» принятым решением.')
issues_schema=arr(string(),'Перечисли основные нерешённые вопросы, проблемы, ограничения и риски. Объединяй повторы, сохраняй неопределённость и не добавляй решения от себя.')
updates_schema=obj({'summary':string('Кратко объясни тему и итоги встречи по-русски.'),'updates':arr(string(),'Основные сообщённые результаты, текущая работа и состояние проекта. Не выдавай планы за завершённую работу.')},'Сожми длинный диалог в краткое резюме и сообщения о прогрессе.')
tasks_schema=arr(task,'Извлеки основные явные будущие поручения, обязательства и предложения о работе. Разделяй статусы. Не включай административные реплики о порядке разговора или гипотетические примеры. Указывай только подтверждённые атрибуты.')
protocol_schema=obj({'summary':string('Краткие тема и итоги встречи.'),'tasks':tasks_schema,'decisions':decision_schema,'issues':issues_schema,'updates':arr(string(),'Основные сообщённые результаты и текущая работа.')},'Составь содержательный краткий протокол полного диалога: основные будущие действия, решения отдельно от предложений, нерешённые вопросы и прогресс. Ответ только по тексту, без выдуманных участников, дат и приоритетов.')
SCHEMAS={'protocol':protocol_schema,'tasks':tasks_schema,'decisions':decision_schema,'issues':issues_schema,'updates':updates_schema}
for schema in SCHEMAS.values():Draft202012Validator.check_schema(schema)

def render(r,lang):
    return '\n'.join(f"[U{u['turn_id']:05d}] {u['speaker']} ({u['start']:.3f}–{u['end']:.3f} с): {u['text_'+lang]}" for u in r['utterances'])

def main():
    rows=json.loads((B/'selected_ru.json').read_text(encoding='utf-8'))
    cards=json.loads((B/'cards_final.json').read_text(encoding='utf-8'))
    corrections=json.loads((B/'turn_corrections.json').read_text(encoding='utf-8'))
    OUT.mkdir(exist_ok=True)
    for d in ['sources','schemas','licenses','scripts']:(OUT/d).mkdir(exist_ok=True)
    all_rows=[];meetings=[];provenance=[];counts=Counter();reviewed_turns=0
    val={'Bro007','Bed012'};test={'Bmr025','Bro022'}
    for r in rows:
        m=r['meeting_id'];c=cards[m]
        split='validation' if m in val else 'test' if m in test else 'train'
        for u in r['utterances']:
            key=m+':'+str(u['turn_id'])
            if key in corrections:
                u['text_ru']=corrections[key];u['translation_review']='assistant_polished';reviewed_turns+=1
            else:u['translation_review']='automatic_not_individually_reviewed'
        for a in r['annotations']:
            a['original_annotation']='human'
            a['translation_review']='automatic_not_individually_reviewed'
        by_turn={u['turn_id']:u for u in r['utterances']}
        annotation_ids={a['id'] for a in r['annotations']}
        tasks=[];task_sources=[]
        for j,t in enumerate(c['tasks']):
            ann,action,owners,deadline,conditions,status,turn_ids=t
            assert turn_ids, (m,action,'missing evidence')
            if ann:assert m+'.'+ann in annotation_ids
            ev=[{'turn_id':i,'quote':by_turn[i]['text_ru']} for i in turn_ids]
            tasks.append({'action':action,'owners':owners,'deadline':deadline,'conditions':conditions,'status':status,'evidence':ev})
            counts['tasks_'+status]+=1
            task_sources.append({'task_index':j,'source_annotation_id':m+'.'+ann if ann else None,'source_dialogue_act_ids':[by_turn[i]['id'] for i in turn_ids],'english_evidence':[by_turn[i]['text_en'] for i in turn_ids]})
        decisions={'accepted':c['decisions'],'proposed':c['proposals']}
        outputs={'protocol':{'summary':c['summary'],'tasks':tasks,'decisions':decisions,'issues':c['issues'],'updates':c['updates']},'tasks':tasks,'decisions':decisions,'issues':c['issues'],'updates':{'summary':c['summary'],'updates':c['updates']}}
        text_ru=render(r,'ru');text_en=render(r,'en')
        assert not re.search(r'ZXQ\s*\d|\[PENDING\]',text_ru)
        for owner in {x for t in tasks for x in t['owners']}:
            assert owner in text_ru, (m,owner,'not present in Russian input')
        for t in tasks:
            for e in t['evidence']:assert e['quote']==by_turn[e['turn_id']]['text_ru'] and e['quote'] in text_ru
        for view,output in outputs.items():
            schema=SCHEMAS[view];Draft202012Validator(schema).validate(output)
            input_text='<schema>'+dumps(schema)+'</schema>\n<text>'+text_ru+'</text>'
            rec={'id':m+'_'+view,'input':input_text,'output':dumps(output),'metadata':{'meeting_id':m,'view':view,'split':split,'language':'ru','source_language':'en','source_corpus':'ICSI','source_release':'1.0 contributed annotations','meeting_type':'naturally_occurring_research_meeting','source_license':'CC-BY-4.0','target_review':'assistant_authored_and_reviewed_from_human_annotations_and_selected_dialogue','translation_review':'automatic_with_selected_assistant_corrections','full_meeting':True,'truncated':False}}
            assert json.loads(rec['output'])==output
            assert rec['input'].startswith('<schema>') and rec['input'].endswith('</text>')
            all_rows.append(rec)
        (OUT/'sources'/(m+'.en.txt')).write_text(text_en,encoding='utf-8')
        (OUT/'sources'/(m+'.ru.txt')).write_text(text_ru,encoding='utf-8')
        (OUT/'sources'/(m+'.aligned.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
        meetings.append({'meeting_id':m,'split':split,'utterances':len(r['utterances']),'english_words':sum(len(u['text_en'].split()) for u in r['utterances']),'russian_words':sum(len(u['text_ru'].split()) for u in r['utterances']),'russian_text_chars':len(text_ru),'source_annotations':len(r['annotations']),'tasks':len(tasks),'accepted_decisions':len(c['decisions']),'proposed_options':len(c['proposals']),'issues':len(c['issues']),'updates':len(c['updates'])})
        f=SRC/'Contributions/Summarization/abstractive'/(m+'.abssumm.xml')
        provenance.append({'meeting_id':m,'corpus_source':'https://groups.inf.ed.ac.uk/ami/icsi/','download_url':'https://groups.inf.ed.ac.uk/ami/ICSICorpusAnnotations/ICSI_plus_NXT.zip','release':'ICSI core plus contributed annotations v1.0','source_summary_xml_sha256':sha(f),'english_transcript_sha256':hashlib.sha256(text_en.encode()).hexdigest(),'source_summary_sentences':r['annotations'],'target_task_provenance':task_sources,'changes':['Chronological rendering of dialogue acts; nonlexical noise events omitted.','English-to-Russian sentence translation with a protected terminology glossary.','Selected action evidence translated/polished by the assistant.','Russian compact summaries and structured task/decision labels authored by the assistant using the original human annotations and dialogue evidence.']})
    assert len(all_rows)==100 and len(meetings)==20
    for split in ['all','train','validation','test']:
        selected=all_rows if split=='all' else [x for x in all_rows if x['metadata']['split']==split]
        (OUT/(split+'.jsonl')).write_text(''.join(dumps(x)+'\n' for x in selected),encoding='utf-8')
    for name,schema in SCHEMAS.items():(OUT/'schemas'/(name+'.schema.json')).write_text(json.dumps(schema,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'meetings.json').write_text(json.dumps(meetings,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'provenance.jsonl').write_text(''.join(dumps(x)+'\n' for x in provenance),encoding='utf-8')
    # Input and output only, ready for encoder-decoder training.
    (OUT/'t5_pairs.jsonl').write_text(''.join(dumps({'input':x['input'],'output':x['output']})+'\n' for x in all_rows),encoding='utf-8')
    split_ids={s:{r['meeting_id'] for r in meetings if r['split']==s} for s in ['train','validation','test']}
    for s in split_ids:
        for t in split_ids:
            if s!=t:assert not(split_ids[s]&split_ids[t])
    chars=[m['russian_text_chars'] for m in meetings];words=[m['russian_words'] for m in meetings]
    report={'examples':100,'unique_full_meetings':20,'schema_families':5,'splits':{'train':80,'validation':10,'test':10},'unique_meetings_per_split':{k:len(v) for k,v in split_ids.items()},'source_utterances':sum(m['utterances'] for m in meetings),'original_human_summary_sentences':sum(m['source_annotations'] for m in meetings),'unique_tasks':sum(m['tasks'] for m in meetings),'task_statuses':dict(counts),'accepted_decisions':sum(m['accepted_decisions'] for m in meetings),'proposed_options':sum(m['proposed_options'] for m in meetings),'issues':sum(m['issues'] for m in meetings),'updates':sum(m['updates'] for m in meetings),'english_words':sum(m['english_words'] for m in meetings),'russian_text_chars':{'min':min(chars),'median':statistics.median(chars),'max':max(chars)},'russian_words_per_meeting':{'min':min(words),'median':statistics.median(words),'max':max(words)},'assistant_polished_utterances':reviewed_turns,'checks':{'draft_2020_12_schema_validation':'100/100 passed','json_roundtrip':'100/100 passed','evidence_exact_in_input':'all task quotations passed','nonempty_evidence_for_every_task':'passed','owner_spelling_present_in_input':'passed','meeting_split_overlap':'none','truncation':'none'},'limitations':['100 pairs are five views of 20 meetings, not 100 independent meetings.','Russian transcripts are machine translated; only selected passages were individually polished.','Targets are assistant annotations grounded in English human summaries and selected dialogue evidence; no independent human review.','Extraction covers salient business/research content, not a certified exhaustive annotation of every possible action or fact.','The same project and participants can recur across splits; split is by meeting, not by participant or project.','Source meetings are public benchmark data, so this is not a novel contamination-free evaluation set.','No model tokenizer or context limit was provided; full inputs can exceed a T5 configuration.']}
    (OUT/'quality_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'licenses'/'ICSI_CC_BY_4_0.txt').write_bytes((SRC/'LICENCE.txt').read_bytes())
    (OUT/'licenses'/'ICSI_summarization_README.txt').write_bytes((SRC/'Contributions/Summarization/README').read_bytes())
    for fn in ['parse_icsi.py','translate_icsi.py','build_dataset.py','refine_cards.py','reviewed_cards.json','reviewed_cards_second.json','turn_corrections.json']:
        shutil.copy2(B/fn,OUT/'scripts'/fn)
    model_info={'model':'Helsinki-NLP/opus-mt-en-ru','url':'https://huggingface.co/Helsinki-NLP/opus-mt-en-ru','weights_sha256':sha(B/'opus_original/pytorch_model.bin'),'runtime':'CTranslate2 INT8 CPU','beam_size':3,'repetition_penalty':1.05,'source_eos_appended':True,'sentence_segmentation':'all sentences translated separately; long sentences split on word boundaries; no silent truncation','cache_checkpointed':True}
    (OUT/'translation_method.json').write_text(json.dumps(model_info,ensure_ascii=False,indent=2),encoding='utf-8')
    shutil.copy2(B/'README_RU.md',OUT/'README.md')
    zip_path=B.parent/'meetings_ru_100.zip'
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(OUT.rglob('*')):
            if f.is_file():z.write(f,f.relative_to(OUT.parent))
    print(json.dumps(report,ensure_ascii=False,indent=2));print('archive',zip_path,zip_path.stat().st_size)

if __name__=='__main__':main()
