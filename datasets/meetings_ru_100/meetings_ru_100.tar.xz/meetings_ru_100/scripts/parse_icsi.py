from pathlib import Path
import json,re,xml.etree.ElementTree as ET

BASE=Path(__file__).parent
SRC=BASE/'icsi_annotations'/'ICSIplus'
NS='{http://nite.sourceforge.net/}'
MEETINGS=['Bro015','Bro007','Bro008','Bro013','Bro011','Bro025','Bed017','Bed012','Bed016','Bmr025','Bro016','Bed009','Bed004','Bro010','Bmr012','Bro022','Bed010','Bmr026','Bro021','Bed011']

def parse_ref(href, sequences, objects):
    fname,frag=href.split('#',1)
    ids=re.findall(r'id\(([^)]+)\)',frag)
    if len(ids)==1:return [objects[ids[0]]]
    seq=sequences[fname];positions={x['id']:i for i,x in enumerate(seq)}
    return seq[positions[ids[0]]:positions[ids[1]]+1]

def load(m):
    sequences={};objects={}
    for f in sorted((SRC/'Words').glob(m+'.*.xml')):
        seq=[]
        for x in ET.parse(f).getroot():
            item={'id':x.get(NS+'id'),'text':x.text or '', 'tag':x.tag}
            seq.append(item);objects[item['id']]=item
        sequences[f.name]=seq
    utterances=[]
    for f in sorted((SRC/'DialogueActs').glob(m+'.*.xml')):
        speaker=f.name.split('.')[1];seq=[]
        for x in ET.parse(f).getroot():
            parts=[]
            for ch in x.findall(NS+'child'):
                parts+=parse_ref(ch.get('href'),sequences,objects)
            text=' '.join(w['text'] for w in parts if w['tag']=='w').strip()
            text=re.sub(r'\s+([.,!?;:])',r'\1',text)
            text=re.sub(r"\s+('s|'re|'ve|'ll|'d|n't)\b",r'\1',text)
            u={'id':x.get(NS+'id'),'speaker':x.get('participant') or speaker,'channel':speaker,'start':float(x.get('starttime') or 0),'end':float(x.get('endtime') or 0),'text_en':text}
            seq.append(u);objects[u['id']]=u
            if text:utterances.append(u)
        sequences[f.name]=seq
    utterances.sort(key=lambda u:(u['start'],u['end'],u['id']))
    for i,u in enumerate(utterances):u['turn_id']=i
    turn_by_id={u['id']:u for u in utterances}
    root=ET.parse(SRC/'Contributions/Summarization/abstractive'/(m+'.abssumm.xml')).getroot()
    annotations=[]
    for sec in root:
        for x in sec:
            txt=' '.join(x.itertext()).strip()
            if txt and txt not in ['*NA*','N/A','NA']:
                annotations.append({'id':x.get(NS+'id'),'section':sec.tag,'text_en':txt,'evidence_turn_ids':[]})
    ann_by_id={a['id']:a for a in annotations}
    f=SRC/'Contributions/Summarization/extractive'/(m+'.summlink.xml')
    if f.exists():
        for x in ET.parse(f).getroot():
            pointers={y.get('role'):y.get('href') for y in x.findall(NS+'pointer')}
            a_id=re.findall(r'id\(([^)]+)\)',pointers.get('abstractive',''))
            if not a_id or a_id[0] not in ann_by_id:continue
            refs=parse_ref(pointers['extractive'],sequences,objects)
            ann_by_id[a_id[0]]['evidence_turn_ids']+= [turn_by_id[y['id']]['turn_id'] for y in refs if y['id'] in turn_by_id]
    for a in annotations:a['evidence_turn_ids']=sorted(set(a['evidence_turn_ids']))
    return {'meeting_id':m,'utterances':utterances,'annotations':annotations}

if __name__=='__main__':
    rows=[load(m) for m in MEETINGS]
    (BASE/'selected_en.json').write_text(json.dumps(rows,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({'meetings':len(rows),'turns':sum(len(r['utterances']) for r in rows),'words':sum(len(u['text_en'].split()) for r in rows for u in r['utterances']),'annotations':sum(len(r['annotations']) for r in rows)}))
