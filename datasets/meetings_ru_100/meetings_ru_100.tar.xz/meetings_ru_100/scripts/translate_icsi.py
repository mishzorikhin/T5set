"""Translate all selected utterances with a local OPUS-MT model; checkpoint every batch."""
from pathlib import Path
import json,re,time,hashlib
import ctranslate2,sentencepiece

BASE=Path(__file__).parent
SRC=BASE/'opus_original'
MODEL=BASE/'opus_ct2'
CACHE=BASE/'translation_cache_protected.jsonl'
rows=json.loads((BASE/'selected_en.json').read_text())
src=sentencepiece.SentencePieceProcessor(model_file=str(SRC/'source.spm'))
tgt=sentencepiece.SentencePieceProcessor(model_file=str(SRC/'target.spm'))
translator=ctranslate2.Translator(str(MODEL),device='cpu',compute_type='int8',intra_threads=8,inter_threads=1)
cache={}
if CACHE.exists():
    for line in CACHE.read_text().splitlines():
        r=json.loads(line);cache[r['en']]=r['ru']
short={'yeah':'Да.','yes':'Да.','no':'Нет.','okay':'Хорошо.','ok':'Хорошо.','right':'Верно.','uh':'Э-э.','um':'Эм.','mm-hmm':'Угу.','mhm':'Угу.','hmm':'Хм.','oh':'О.','uh-huh':'Угу.','thanks':'Спасибо.','thank you':'Спасибо.','sure':'Конечно.','good':'Хорошо.'}
glossary={
 'Berkeley Meeting Recorder Group':'группа проекта Meeting Recorder в Беркли',
 'Berkeley Meeting Recorder group':'группа проекта Meeting Recorder в Беркли',
 'Berkley Meeting Recorder Group':'группа проекта Meeting Recorder в Беркли',
 'Berkeley Meeting Recorder':'проект Meeting Recorder в Беркли',
 'Meeting Recorder corpus':'корпус Meeting Recorder',
 'Meeting Recorder Group':'группа проекта Meeting Recorder',
 'Meeting Recorder':'Meeting Recorder',
 'word error rates':'частота ошибок распознавания слов',
 'word error rate':'частота ошибок распознавания слов',
 'insertion penalties':'штрафы за вставки',
 'mel cepstrum':'мел-кепстр',
 'belief-nets':'байесовские сети','belief - nets':'байесовские сети',
 'belief-net':'байесовская сеть','belief - net':'байесовская сеть',
 'belief net':'байесовская сеть','Bayes-net':'байесовская сеть',
 'phonetics':'фонетика','phonetic':'фонетический',
 'phones':'фонемы','phone':'фонема',
 'state-transition network':'сеть переходов между состояниями',
 'cross pads':'CrossPads','cross-pads':'CrossPads',
 'SmartKom':'SmartKom','JavaBayes':'JavaBayes','Transcriber':'Transcriber',
 'Linux':'Linux','Prolog':'Prolog','Java':'Java','Hugin':'Hugin',
 'Powerpoint':'PowerPoint','PowerPoint':'PowerPoint',
 'Aurora':'Aurora','CrossPads':'CrossPads','SpeechCorder':'SpeechCorder',
 'HTK':'HTK','ICSI':'ICSI','OGI':'OGI','SRI':'SRI','LDC':'LDC',
 'DARPA':'DARPA','MFCCs':'MFCC','MFCC':'MFCC','MSG':'MSG','KLT':'KLT',
 'VAD':'VAD','XML':'XML','PRM':'PRM','NTL':'NTL','EML':'EML','DFKI':'DFKI',
 'fMRI':'fMRI','NW archive':'NW archive','PZMs':'PZM','PZM':'PZM',
}
entity_pattern=re.compile('|'.join(re.escape(k) for k in sorted(glossary,key=len,reverse=True))+r'|\b(?:me|mn|fe|fn)\d{3}\b')
def protect(text):
    values=[]
    def repl(m):
        values.append(glossary.get(m.group(),m.group()))
        return 'ZXQ'+str(len(values)-1)
    return entity_pattern.sub(repl,text),values
def restore(text,values):
    # Also accept whitespace inserted between the marker and its index.
    for i,v in reversed(list(enumerate(values))):
        pattern=r'(?i)Z\s*X\s*Q\s*'+str(i)+r'(?!\d)'
        text=re.sub(pattern,lambda m:v,text)
    if re.search(r'(?i)ZXQ\s*\d',text):raise ValueError('Unrestored marker: '+text)
    return text

def segments(text):
    # One sentence at a time: Marian can prematurely stop after sentence one.
    sentences=re.split(r'(?<=[.!?])\s+(?=[A-Z0-9])',text)
    out=[]
    for s in sentences:
        ids=src.encode(s,out_type=str)
        if len(ids)<=220:out.append(s)
        else:
            # Split on source word boundaries; never discard text.
            buf=[]
            for w in s.split():
                if buf and len(src.encode(' '.join(buf+[w]),out_type=str))>220:
                    out.append(' '.join(buf));buf=[]
                buf.append(w)
            if buf:out.append(' '.join(buf))
    return [s for s in out if s.strip()]

pending=[];seen=set()
# First translate the complete human annotation, then the source utterances.
texts=[a['text_en'] for r in rows for a in r['annotations']]+[u['text_en'] for r in rows for u in r['utterances']]
for text in texts:
    for s in segments(text):
        if s in cache or s in seen:continue
        seen.add(s)
        normalized=s.lower().strip(' .,!?;:')
        if normalized in short:cache[s]=short[normalized]
        elif not re.search(r'[a-zA-Z]',s):cache[s]=s
        else:pending.append(s)
print('segments',len(pending),'cached',len(cache),flush=True)
start=time.time()
with CACHE.open('a',encoding='utf-8') as f:
    for i in range(0,len(pending),48):
        batch=pending[i:i+48]
        protected=[protect(s) for s in batch]
        tokens=[src.encode(s,out_type=str)+['</s>'] for s,values in protected]
        results=translator.translate_batch(tokens,beam_size=3,max_batch_size=48,batch_type='examples',max_decoding_length=300,repetition_penalty=1.05)
        for en,result,(protected_text,values) in zip(batch,results,protected):
            ru=restore(tgt.decode(result.hypotheses[0]).strip(),values)
            if not ru:raise ValueError('Empty translation: '+en)
            cache[en]=ru;f.write(json.dumps({'en':en,'ru':ru},ensure_ascii=False)+'\n')
        f.flush()
        if i%480==0:print('progress',min(i+48,len(pending)),len(pending),'elapsed',round(time.time()-start),flush=True)
        if i<480:
            (BASE/'annotations_ru_preview.json').write_text(json.dumps([{'meeting_id':r['meeting_id'],'annotations':[{**a,'text_ru':' '.join(cache.get(s,'[PENDING]') for s in segments(a['text_en']))} for a in r['annotations']]} for r in rows],ensure_ascii=False,indent=2),encoding='utf-8')

for r in rows:
    for u in r['utterances']:u['text_ru']=' '.join(cache[s] for s in segments(u['text_en']))
    for a in r['annotations']:a['text_ru']=' '.join(cache[s] for s in segments(a['text_en']))
    (BASE/('translated_'+r['meeting_id']+'.json')).write_text(json.dumps(r,ensure_ascii=False),encoding='utf-8')
(BASE/'selected_ru.json').write_text(json.dumps(rows,ensure_ascii=False),encoding='utf-8')
print('done',len(rows),round(time.time()-start),flush=True)
