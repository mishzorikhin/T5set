"""pip install transformers sentencepiece; use the actual training tokenizer."""
import argparse, json, statistics
from pathlib import Path
from transformers import AutoTokenizer

p=argparse.ArgumentParser()
p.add_argument('--tokenizer',required=True,help='HF checkpoint or local tokenizer path')
p.add_argument('--data',required=True,type=Path)
p.add_argument('--max-input',type=int,default=2048)
p.add_argument('--max-output',type=int,default=512)
p.add_argument('--report',type=Path)
a=p.parse_args()
tokenizer=AutoTokenizer.from_pretrained(a.tokenizer)
inputs=[];outputs=[];violations=[]
for i,line in enumerate(a.data.read_text().splitlines(),1):
    r=json.loads(line)
    il=len(tokenizer(r['input'],add_special_tokens=True,truncation=False)['input_ids'])
    ol=len(tokenizer(r['output'],add_special_tokens=True,truncation=False)['input_ids'])
    inputs.append(il);outputs.append(ol)
    if il>a.max_input or ol>a.max_output:
        violations.append(dict(line=i,id=r.get('id'),input_tokens=il,output_tokens=ol))
report=dict(tokenizer=a.tokenizer,rows=len(inputs),limits=dict(input=a.max_input,output=a.max_output),
 input=dict(min=min(inputs),median=statistics.median(inputs),max=max(inputs)),
 output=dict(min=min(outputs),median=statistics.median(outputs),max=max(outputs)),violations=violations)
s=json.dumps(report,ensure_ascii=False,indent=2)
print(s)
if a.report:a.report.write_text(s+'\n')
raise SystemExit(1 if violations else 0)
