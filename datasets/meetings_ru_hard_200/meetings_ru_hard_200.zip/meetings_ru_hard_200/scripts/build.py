import json, copy, hashlib, statistics, random, zipfile
from pathlib import Path
import sentencepiece as spm
from jsonschema import Draft202012Validator
from long_context import expand

W=Path(__file__).parent
OUT=W/'meetings_ru_hard_200'
OUT.mkdir(exist_ok=True)
sources=json.loads((W/'sources_authored.json').read_text())
tok=spm.SentencePieceProcessor(model_file=str(W/'spiece.model'))
def nt(s): return len(tok.encode(s))+1 # EOS, T5 legacy SentencePiece encoding
def obj(props,desc):
    return {'description':desc,'type':'object','properties':props,'required':list(props),'additionalProperties':False}
def arr(items,desc=None):
    r={'type':'array','items':items}
    if desc:r['description']=desc
    return r
string={'type':'string'}
nullable={'type':['string','null']}
strings=arr(string)
schemas={
 'tasks':arr(obj({'action':string,'owners':strings,'deadline':nullable,'condition':nullable,
    'status':{'type':'string','enum':['committed','requested','conditional']},'evidence':strings},
    'Текущие поручения после всех уточнений. committed — принято; requested — просьба без принятия; conditional — принято с условием. owners: только названные владельцы, иначе []. deadline: как в тексте, иначе null. evidence: ID реплик, обосновывающих итог. Не включать идеи, завершённое и отменённое. Объединять шаги одной работы.')),
 'minutes':obj({'summary':string,'decisions':strings,'open_questions':strings},
    'Краткий итог всей встречи: 1–3 предложения, принятые решения и явно неразрешённые вопросы. Предложение не является решением. Сохранять последнее уточнение. Не превращать неизвестное в утверждение.'),
 'owners':obj({'assigned':arr(obj({'owners':strings,'actions':strings},'Одна группа явно названных владельцев и её текущие работы.')),'unassigned':strings},
    'Текущие поручения сгруппировать по явно названным владельцам; совместные команды не разделять. Без владельца — unassigned. Условные принятые поручения включить. Завершённое, идеи и отменённое исключить. Названия действий краткие, как в текущем перечне задач.'),
 'history':obj({'cancelled':strings,'proposals':strings,'completed':strings},
    'Извлечь только явно отменённые прежние поручения, предложенные но не принятые действия и явно завершённые работы. Не включать текущие задачи. Отклонённую идею оставить в proposals; снятое прежнее поручение — cancelled. Не извлекать общие инструкции как поручения.')
}

# Контрастные варианты: меняется поздняя договорённость, а не только имя в шаблоне.
def variant(baseid,speaker,text,mutate):
    s=copy.deepcopy(next(x for x in sources if x['id']==baseid))
    s['id']=baseid+'b'
    uid=f'U{len(s["turns"])+1:02}'
    s['turns'].append(dict(id=uid,speaker=speaker,text=text))
    s['contrast_of']=baseid
    mutate(s,uid)
    sources.append(s)
def replace_first(s,u,owner=None,due=None,summary=None,decision=None):
    if owner:s['tasks'][0]['owner']=owner
    if due:s['tasks'][0]['due']=due
    s['tasks'][0]['evidence'].append(u)
    if summary:s['summary']=summary
    if decision:s['decisions'].append(decision)

def v1(s,u):
    s['decisions']=[x for x in s['decisions'] if not x.startswith('Срок сравнения')]
    replace_first(s,u,due='к следующему вторнику',summary='Переключение биллинга ждёт проверки возвратов. Павел отправит сравнение к следующему вторнику; промежуточный срок четверга отменён.',decision='Окончательный срок сравнения — следующий вторник.')
variant('m01','Лена','Поправка в самом конце: по просьбе финансов Павел пришлёт сравнение к следующему вторнику. Павел подтвердил это в чате прямо сейчас. Четверг больше не действует.',v1)
def v2(s,u):
    s['tasks'][0]['action']='Получить у закупщика актуальную карточку компании'
    replace_first(s,u,due='до конца сегодняшнего дня',summary='Подписание договора приостановлено до актуальной карточки и подтверждения версии. Даша получит карточку до конца сегодняшнего дня, а не завтра.',decision='Срок получения карточки изменён на конец сегодняшнего дня.')
variant('m02','Алла','Даша только что подтвердила ускорение: карточку получит до конца сегодняшнего дня. Завтрашний обед в протокол не переносим. Остальные ограничения прежние.',v2)
def v3(s,u):
    s['dropped']=[t['action']+'.' for t in s['tasks']]
    s['tasks']=[]
    s['decisions']=['Приостановить эксперимент на две недели.','Снять передачу выгрузки и пересчёт конверсий.','Не увеличивать бюджет до возобновления эксперимента.']
    s['questions']=['Когда эксперимент будет возобновлён?']
    s['summary']='Эксперимент приостановлен на две недели; передача выгрузки и пересчёт конверсий сняты. Активных поручений по эксперименту не осталось.'
variant('m03','Вера','Стоп, пришло решение руководства: эксперимент приостанавливаем на две недели. Передачу выгрузки Кириллом и пересчёт Светой снимаю. Никаких активных задач по эксперименту сейчас нет, остальные идеи остаются идеями.',v3)
def v4(s,u):
    s['dropped'].append('Маша проверит вчерашние коробки без записи о сканировании.')
    replace_first(s,u,owner='Юля',summary='После восстановления принтера несосканированные коробки проверит Юля вместо Маши. Юра найдёт номера двух коробок без маркировки.',decision='Проверку коробок передать Юле вместо Маши.')
variant('m04','Олег','Машу вызывают на другую смену. Проверку коробок в том же объёме и до конца смены передаю Юле, она согласилась. Новый исполнитель — Юля. Маша эту задачу больше не выполняет. По поиску номеров Юрой ничего не меняем.',v4)
def v5(s,u):
    s['dropped'].append(s['tasks'][0]['action']+'.')
    s['tasks']=s['tasks'][1:]
    s['decisions'].append('Снять условную проверку возврата с Дениса до отдельного назначения.')
    s['summary']='Запуск в понедельник не подтверждён. Паша запросит пример возврата и предупредит продажи; условная проверка Дениса снята даже при получении примера.'
variant('m05','Нина','Последнее изменение: Дениса переводят на другой проект. Его проверку возврата снимаем полностью, даже если пример придёт вовремя. Нового проверяющего сегодня не назначаем. Обе сегодняшние задачи Паши остаются.',v5)
def v7(s,u):
    s['tasks'][1]['status']='committed'
    s['tasks'][1]['condition']=None
    s['tasks'][1]['due']='до конца сегодняшнего дня'
    s['tasks'][1]['evidence'].append(u)
    s['questions']=[]
    s['decisions'].append('Использовать полученное пояснение клиента для проверки остатков сегодня.')
    s['summary']='Клиент прислал распределение платежа прямо на встрече. Антон всё ещё уточнит его у клиента до завтра, а Женя уже сегодня проверит остатки по имеющемуся пояснению.'
variant('m07','Люда','Пока говорили, клиент прислал распределение. Женя подтверждает: остатки проверит до конца сегодняшнего дня по этому письму, уже без условия ожидания ответа. Уточнение Антона до завтра оставляем, чтобы отдельно подтвердить трактовку письма.',v7)
def v8(s,u):
    s['decisions']=[x for x in s['decisions'] if not x.startswith('Провести финальный')]
    s['tasks'][0]['action']='Согласовать с руководителем слот финального разговора только с Артёмом'
    s['tasks'][0]['evidence'].append(u)
    s['decisions'].append('Финальный разговор согласовать только с Артёмом: второй кандидат отказался.')
    s['summary']='Второй кандидат отказался, поэтому Мила согласует финальный разговор только с Артёмом до вторника. Илья исправит название проекта; оффер ещё не принят.'
variant('m08','Оля','Пришло письмо: второй кандидат отказался. Мила подтверждает, что до вторника согласует разговор только с Артёмом. Задачу Ильи оставляем. Это ещё не решение выдать оффер.',v8)
def v9(s,u):
    s['decisions']=[x for x in s['decisions'] if not x.startswith('Проверку выполняет')]
    s['tasks']=[]
    s['completed'].append('Проверить комплектность и серийный номер сканера и приложить фото к акту осмотра.')
    s['questions']=[]
    s['summary']='Осмотр сканера завершён прямо во время созвона: комплект полный, номер совпал, фото в акте. Новых поручений по возврату не осталось.'
variant('m09','Глеб','Пока слушал, уже закончил весь осмотр: комплект полный, номер совпадает, фото приложено к акту. Надя подтверждает закрытие моей проверки прямо сейчас. Завтрашняя проверка больше не нужна, других поручений нет.',v9)
def v11(s,u):
    s['tasks'][0]['due']='к пятнице'
    s['tasks'][0]['evidence'].append(u)
    s['decisions'].append('Внутренний разбор перенести со среды на пятницу.')
    s['summary']='Сервис восстановлен, причина не установлена. Стас подготовит разбор к пятнице вместо среды; Федя сегодня сообщит клиентам о восстановлении без указания причины.'
variant('m11','Кира','Стас попросил ещё два дня на логи и подтвердил новый срок. Разбор теперь к пятнице, не к среде. Письмо Феди по-прежнему сегодня. Это не обещание установить причину к пятнице.',v11)

assert len(sources)==50
sources=[expand(s) for s in sources]
def owners(t):return t['owner'].split('; ') if t['owner'] else []
def target(s,view):
    if view=='tasks':
        return [dict(action=t['action'],owners=owners(t),deadline=t['due'],condition=t['condition'],status=t['status'],evidence=t['evidence']) for t in s['tasks']]
    if view=='minutes':return dict(summary=s['summary'],decisions=s['decisions'],open_questions=s['questions'])
    if view=='history':return dict(cancelled=s['dropped'],proposals=s['ideas'],completed=s['completed'])
    assigned={};unassigned=[]
    for t in s['tasks']:
        if not owners(t):unassigned.append(t['action'])
        else:
            k=tuple(owners(t));assigned.setdefault(k,[]).append(t['action'])
    return dict(assigned=[dict(owners=list(k),actions=v) for k,v in assigned.items()],unassigned=unassigned)

def raw(s):
    return s['context']+'\n\n'+'\n'.join(f'[{t["id"]}] {t["speaker"]}: {t["text"]}' for t in s['turns'])
def compact(o):return json.dumps(o,ensure_ascii=False,separators=(',',':'))

families=list(dict.fromkeys(s['family'] for s in sources))
random.Random(731).shuffle(families)
splits={f:('test' if i<5 else 'validation' if i<10 else 'train') for i,f in enumerate(families)}
records=[]
for s in sources:
    text=raw(s)
    ids={t['id'] for t in s['turns']}
    for t in s['tasks']:
        assert t['evidence'] and set(t['evidence'])<=ids
        assert (t['status']=='conditional') == (t['condition'] is not None)
        assert t['owner'] is None or all(o in text for o in owners(t)),(s['id'],t['owner'])
        assert t['due'] is None or t['due'].lower() in text.lower(), (s['id'],t['due'])
    for view,schema in schemas.items():
        Draft202012Validator.check_schema(schema)
        output=target(s,view)
        Draft202012Validator(schema).validate(output)
        inp=f'<schema>{compact(schema)}</schema>\n<text>{text}</text>'
        rec=dict(id=s['id']+'_'+view,input=inp,output=compact(output),metadata=dict(
            source_id=s['id'],family_id=s['family'],view=view,split=splits[s['family']],language='ru',
            origin='assistant_authored_synthetic',annotation='assistant_authored_not_independent_human_gold',
            contrast_of=s.get('contrast_of'),long_context=s.get('long_context',False),input_tokens_mt5=nt(inp),output_tokens_mt5=nt(compact(output)),
            text_tokens_mt5=nt(text),input_sha256=hashlib.sha256(inp.encode()).hexdigest()))
        assert nt(inp)<=2048,(s['id'],view,nt(inp))
        records.append(rec)
for subset in ['all','long_context','train','validation','test']:
    rr=records if subset=='all' else ([r for r in records if r['metadata']['long_context']] if subset=='long_context' else [r for r in records if r['metadata']['split']==subset])
    (OUT/f'{subset}.jsonl').write_text(''.join(compact(r)+'\n' for r in rr))
    if subset not in ('all','long_context'):
        (OUT/f'{subset}_pairs.jsonl').write_text(''.join(compact(dict(input=r['input'],output=r['output']))+'\n' for r in rr))
(OUT/'sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n')
(OUT/'schemas.json').write_text(json.dumps(schemas,ensure_ascii=False,indent=2)+'\n')
lengths=[r['metadata']['input_tokens_mt5'] for r in records]
report=dict(examples=len(records),unique_inputs=len({r['input'] for r in records}),source_texts=len(sources),
 independent_scenario_families=len(families),contrastive_variants=9,schema_views=len(schemas),
 splits={sp:dict(pairs=sum(r['metadata']['split']==sp for r in records),families=sum(splits[f]==sp for f in families)) for sp in ['train','validation','test']},
 empty_task_sources=sum(not s['tasks'] for s in sources),active_tasks=sum(len(s['tasks']) for s in sources),
 long_context_pairs=sum(r['metadata']['long_context'] for r in records),
 long_context_tokens_mt5=dict(min=min(r['metadata']['input_tokens_mt5'] for r in records if r['metadata']['long_context']),max=max(r['metadata']['input_tokens_mt5'] for r in records if r['metadata']['long_context'])),
 input_tokens_mt5=dict(min=min(lengths),median=statistics.median(lengths),max=max(lengths)),
 output_tokens_mt5=dict(min=min(r['metadata']['output_tokens_mt5'] for r in records),max=max(r['metadata']['output_tokens_mt5'] for r in records)),
 text_chars=dict(min=min(len(raw(s)) for s in sources),median=statistics.median(len(raw(s)) for s in sources),max=max(len(raw(s)) for s in sources)),
 checks={'json_schema':'passed','evidence_ids':'passed','explicit_owner_presence':'passed','explicit_deadline_presence':'passed','input_length_mt5_le_2048':'passed','grouped_split_no_family_overlap':'passed'},
 semantic_review='Assistant-authored and reviewed; no independent human annotation or model-training evaluation.',
 tokenizer={'model':'google/mt5-small','revision':'c83db3e90edd4c0bc69ad9f075c3d19b1ef56c45','method':'SentencePiece encode plus one EOS; no truncation','sha256':hashlib.sha256((W/'spiece.model').read_bytes()).hexdigest()},
 limitation='Lengths verified for the stated mT5 SentencePiece tokenizer only; recheck using the actual training checkpoint.')
(OUT/'quality_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
